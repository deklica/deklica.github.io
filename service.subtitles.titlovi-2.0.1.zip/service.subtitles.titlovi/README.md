# service.subtitles.titlovi  
<b>Official Kodi subtitles addon for Titlovi.com v2.0.1</b>  
System Requirements: Kodi v19 (matrix) or higher  

Search and download subtitles for Movies, Documentaries and TV Series from <b>Titlovi.com</b>.  
Supported languages: English, Serbian, Croatian, Bosnian, Macedonian and Slovenian.  

Ovo je značajno prerađena verzija Titlovi.com dodatka, unapređena boljim performansama, većom pouzdanošću i novim funkcionalnostima.
